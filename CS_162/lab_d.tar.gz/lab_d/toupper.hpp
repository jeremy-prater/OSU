#ifndef TO_UPPER_H
#define TO_UPPER_H

#define LOWER_A 0x61
#define LOWER_Z 0x7A
#define LOWER_TO_UPPER_OFFSET 0x20

#endif // TO_UPPER_H
