#include "common.h"

int main(int argc, char *argv[])
{
    GetServerResponse(argc, argv, OTP_DEC_MAGIC, OTP_DEC_MAGIC);
	return 0;
}
