#include "common.h"

int main(int argc, char *argv[])
{
    GetServerResponse(argc, argv, OTP_ENC_MAGIC, OTP_ENC_MAGIC);
	return 0;
}

